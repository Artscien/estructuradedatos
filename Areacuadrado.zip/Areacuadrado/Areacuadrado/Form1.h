#pragma once

namespace Areacuadrado {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  L;
	protected: 
	private: System::Windows::Forms::Label^  A;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::Button^  BtbCalcular;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->L = (gcnew System::Windows::Forms::Label());
			this->A = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->BtbCalcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// L
			// 
			this->L->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->L->Location = System::Drawing::Point(65, 56);
			this->L->Name = L"L";
			this->L->Size = System::Drawing::Size(59, 28);
			this->L->TabIndex = 0;
			this->L->Text = L"Lado";
			this->L->Click += gcnew System::EventHandler(this, &Form1::L_Click);
			// 
			// A
			// 
			this->A->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->A->Location = System::Drawing::Point(65, 170);
			this->A->Name = L"A";
			this->A->Size = System::Drawing::Size(59, 28);
			this->A->TabIndex = 1;
			this->A->Text = L"Area";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(178, 64);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(142, 20);
			this->textBox1->TabIndex = 2;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &Form1::textBox1_TextChanged);
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(178, 178);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(142, 20);
			this->textBox2->TabIndex = 3;
			// 
			// BtbCalcular
			// 
			this->BtbCalcular->Location = System::Drawing::Point(379, 112);
			this->BtbCalcular->Name = L"BtbCalcular";
			this->BtbCalcular->Size = System::Drawing::Size(87, 39);
			this->BtbCalcular->TabIndex = 4;
			this->BtbCalcular->Text = L"Calcular";
			this->BtbCalcular->UseVisualStyleBackColor = true;
			this->BtbCalcular->Click += gcnew System::EventHandler(this, &Form1::BtbCalcular_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(645, 449);
			this->Controls->Add(this->BtbCalcular);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->A);
			this->Controls->Add(this->L);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void L_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
	private: System::Void BtbCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 int Lado,Area;
				 Lado = System::Convert::ToInt32(textBox1->Text);
				 Area = Lado * Lado;
				 textBox2->Text = Area.ToString();
			 }
};
}

